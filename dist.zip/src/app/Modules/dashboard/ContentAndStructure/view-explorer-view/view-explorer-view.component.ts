import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-explorer-view',
  templateUrl: './view-explorer-view.component.html',
  styleUrls: ['./view-explorer-view.component.css']
})
export class ViewExplorerViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

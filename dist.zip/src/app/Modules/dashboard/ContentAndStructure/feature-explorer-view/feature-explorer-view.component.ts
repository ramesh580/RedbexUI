import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feature-explorer-view',
  templateUrl: './feature-explorer-view.component.html',
  styleUrls: ['./feature-explorer-view.component.css']
})
export class FeatureExplorerViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

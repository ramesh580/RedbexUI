import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-domain-explorer-view',
  templateUrl: './domain-explorer-view.component.html',
  styleUrls: ['./domain-explorer-view.component.css']
})
export class DomainExplorerViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

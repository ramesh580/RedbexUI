export class UserModel {

    
    FirstName:'string';
    userName:'string';
}

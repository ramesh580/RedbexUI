export class LoginResultModel {
    token:'string';
    error:"string";
}

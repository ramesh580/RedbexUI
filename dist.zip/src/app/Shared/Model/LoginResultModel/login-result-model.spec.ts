import { LoginResultModel } from './login-result-model';

describe('LoginResultModel', () => {
  it('should create an instance', () => {
    expect(new LoginResultModel()).toBeTruthy();
  });
});

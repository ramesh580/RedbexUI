import { Component,ViewChild, AfterViewInit,NgModule } from '@angular/core';
import { jqxWindowComponent } from 'node_modules/jqwidgets-scripts/jqwidgets-ts/angular_jqxwindow';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
 

export class AppComponent {
  title = 'UI'; 
  
}
